#Orientaçao a objetos
class Conta:
    def __init__(self,numero,titular,saldo,limite):
        self.__numero = numero;
        self.__titular = titular
        self.__saldo=saldo
        self.__limite = limite

    def extrato(self):
        return f"Cliente: {self.titular.get_nome()}\nConta: {self.__numero} \nSaldo: {self.__saldo}"


