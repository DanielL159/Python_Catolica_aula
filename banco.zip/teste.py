from banco.Cliente import Cliente
from banco.conta import Conta

cliente1 =Cliente('Joao',"Silva","11111-11")
conta1 = Conta('1234',cliente1,20000,'99999999')

print(conta1.extrato())
